<?php

$dsn = 'mysql:host=berlin.iut.local;dbname=dbbamalvezin';
$usr = 'bamalvezin';
$pass = '1whT1wsy';

$rep = __DIR__."/../";

$vues["erreur"] = 'Views/vue_erreur.php';
$vues["main"] = 'Views/vue_principale.php';
$vues["header"] = 'Views/header.php';
$vues["connection"] = 'Views/vue_connection.php';
$vues["inscription"] = 'Views/vue_inscription.php';
$vues["liste"] = 'Views/vue_liste.php';
